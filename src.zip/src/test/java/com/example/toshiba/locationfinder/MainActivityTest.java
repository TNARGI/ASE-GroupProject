package com.example.toshiba.locationfinder;

import android.location.Address;
import android.location.Geocoder;
import com.google.android.gms.maps.GoogleMap;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.junit.Assert.*;
import org.junit.runner.RunWith;

import static org.mockito.Mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Created by Owner on 09/11/2016.
 */
@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class MainActivityTest {

    // Annotate mock dependencies for injection
    @Mock
    Geocoder geoCoder;

    @Mock
    ArrayList<ArrayList<String>> nearbyProperties;

    //@Mock
    //GoogleMap googleMap;

    // Inject mock objects into MainActivity (directly into class variable)
    @InjectMocks private MainActivity mainActivity;

    // Test that getLat/getLon from postcode returns expected output
    @Test
    public void testGetLatLon() throws IOException {

        // Create predetermined output for geocoder
        Address address = Mockito.mock(Address.class);
        // Set return value to something expected
        when(address.getLatitude()).thenReturn(50.8246554);
        when(address.getLongitude()).thenReturn(-0.1740676);
        List<Address> addresses = new ArrayList<>();
        addresses.add(address);

        // Define behaviour for mock geocoder (thows IOException)
        when(geoCoder.getFromLocationName("BN3 2WF", 10)).thenReturn(addresses);

        // Assert that the mocked Address object returns the correct values
        assertEquals(50.8246554, address.getLatitude(), 0);
        assertEquals(-0.1740676, address.getLongitude(), 0);
        // Assert that the mock geocoder was instantiated/injected successfully into mainactivity
        assertNotNull(mainActivity.getGeoCoder());
        // Assert that getLatitudeFromPostcode returns expected value
        // Last parameter of assertEquals is degree of precision for test value comparison
        assertEquals(mainActivity.getLatitudeFromPostcode("BN3 2WF"), 50.8246554, 0);
        // Assert that value of incorrect precision is not returned
        assertNotEquals(mainActivity.getLatitudeFromPostcode("BN3 2WF"), 50.824, 0);
        // Assert that getLongitudeFromPostcode returns expected value
        assertEquals(mainActivity.getLongitudeFromPostcode("BN3 2WF"), -0.1740676, 0);
        assertNotEquals(mainActivity.getLongitudeFromPostcode("BN3 2WF"), 0.1740676, 0);
    }

    // Test that exception is thrown when incorrect coordinates given to GeoCoder
    @Test (expected = IOException.class)
    public void testGeoCoderExceptionThrown() throws IOException {
        // Define that mock geocoder should throw exception with invalid input
        when(geoCoder.getFromLocationName("BNE 2RQ", 10)).thenThrow(new IOException());
        // Call getLat with IOException as expected output
        mainActivity.getLatitudeFromPostcode("BNE 2RQ");
        // Try for longitude
    }

    /*
    // Test edge cases for addNearbyLocMapMarkers
    @Test
    public void testAddNearbyLocMapMarkers() throws IOException {
        when(nearbyProperties.size()).thenReturn(10);
        assertEquals(10, nearbyProperties.size());

        // Create predetermined output for geocoder
        Address address = Mockito.mock(Address.class);
        // Set return value to something expected
        when(address.getLatitude()).thenReturn(50.8246554);
        when(address.getLongitude()).thenReturn(-0.1740676);
        List<Address> addresses = new ArrayList<>();
        addresses.add(address);

        // Define behaviour for mock geocoder (thows IOException)
        when(geoCoder.getFromLocationName("BN3 2WF", 10)).thenReturn(addresses);

        // Define remaining dependencies (set return values for addresslist, otherwise this is currently returning null)
        when(nearbyProperties.get(0).get(2)).thenReturn("BN3 2WF");
        // Value to be tested
        when(nearbyProperties.get(0).get(1)).thenReturn(String.valueOf(20000));

        // Define outputs for googlemap


        mainActivity.addNearbyLocMapMarkers(1);
        // Check which map marker made


    }

    // Test edge cases for addNearbyLocMapMarkers
    @Test
    public void testAddNearbyLocMapMarkersException() throws IOException, IllegalArgumentException {
        when(nearbyProperties.size()).thenReturn(10);
        assertEquals(10, nearbyProperties.size());

        // Create predetermined output for geocoder
        Address address = Mockito.mock(Address.class);
        // Set return value to something expected
        when(address.getLatitude()).thenReturn(50.8246554);
        when(address.getLongitude()).thenReturn(-0.1740676);
        List<Address> addresses = new ArrayList<>();
        addresses.add(address);

        // Define behaviour for mock geocoder (thows IOException)
        when(geoCoder.getFromLocationName("BN3 2WF", 10)).thenReturn(addresses);

        // Define remaining dependencies (set return values for addresslist, otherwise this is currently returning null)
        when(nearbyProperties.get(0).get(2)).thenReturn("BN3 2WF");
        // Value to be tested
        when(nearbyProperties.get(0).get(1)).thenReturn(String.valueOf(-20000));

        // Should throw exception
        mainActivity.addNearbyLocMapMarkers(1);
    }
    */
}