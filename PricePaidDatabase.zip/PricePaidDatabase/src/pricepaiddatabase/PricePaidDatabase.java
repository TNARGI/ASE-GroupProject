package pricepaiddatabase;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Administrator
 */
public class PricePaidDatabase {
    String filePath = "C:/lrppm.txt";
    String host = "jdbc:derby://localhost:1527/db";
    String username = "dn";
    String password = "213";
    //int portNumber = 23456;
    Connection con;
    int nextID;
    ArrayList<ArrayList<String>> dataListArray = new ArrayList();
    //ArrayList<String> dataList = new ArrayList();
    
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        PricePaidDatabase ppd = new PricePaidDatabase();
        ppd.run();
    }
    
    /**
     *
     */
    public void run(){
        try {
            con = DriverManager.getConnection(host, username, password);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        findNextID();
        if(nextID == 0){
            readFile();
        }
        queryData("BN1 7JJ");
        //socketListen();
    }
    
    /**
     *
     * @param id
     * @param price
     * @param postcode
     * @param address
     * @param date
     */
    public void addRecord(int id, int price, String postcode, String address, int date){
        try {
            Statement stmt = con.createStatement();
            String SQL = "INSERT INTO pricepaidtable VALUES (" + id + ", " + price + ", '" + postcode + "', '" + address + "', " + date + ")";
            stmt.execute(SQL);
            stmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    /**
     *
     */
    public void findNextID(){
        try {
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM pricepaidtable";
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()){
                int id = rs.getInt("id");
                nextID = id + 1;
            }
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    /**
     *
     */
    public void displayData(){
        try {
            Statement stmt = con.createStatement();
            String SQL = "SELECT * FROM pricepaidtable";
            ResultSet rs = stmt.executeQuery( SQL );
            while (rs.next()) {
                int id = rs.getInt("id");
                nextID = id + 1;
                int price = rs.getInt("price");
                String date = rs.getString("date");
                String postcode = rs.getString("postcode");
                String address = rs.getString("address");
                System.out.println( id + "; " + price + "; " + date + "; " + postcode + "; " + address);
            }
            System.out.println(nextID);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    /**
     *
     */
    public void readFile(){
        ArrayList<String> tokens = new ArrayList<>();
        String line;
        try {
            FileReader fileReader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while((line = bufferedReader.readLine()) != null) {
                int start = 0;
                int end;
                for(int i = 0; i < 15; i++){
                    if(line.contains(",")){
                        end = line.indexOf(",");
                    } else {
                        end = line.length();
                    }
                    tokens.add(line.substring(++start,end));
                    start = line.indexOf(",");
                    line = line.replaceFirst(",",":");
                }
                int lprice = Integer.parseInt(tokens.get(1));
                int ldate = Integer.parseInt(tokens.get(2).replace("-", "").substring(0,8));
                String lpostcode = tokens.get(3).replace("\"", "");
                String laddress = ((tokens.get(7) + " " + tokens.get(8) + " " +  tokens.get(9) + " " +  tokens.get(10) + " " +  tokens.get(11) + " " +  tokens.get(12) + " " +  tokens.get(13)).replace("\"", "")).replaceAll("( )+", " ");
                //System.out.println(lprice + " " + ldate + " " + lpostcode + " " + laddress);
                //System.out.println(tokens);
                addRecord(nextID, lprice, lpostcode, laddress, ldate);
                nextID++;
                tokens.clear();
            }
            System.out.println("File Read!");
        } catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    /**
     *
     */
    public void socketListen(){
        //String[] phoneInputs = new String[3];
        System.out.println("Listening!");
        while(true){
            try
            (
                ServerSocket serverSocket = new ServerSocket(23456);
                Socket clientSocket = serverSocket.accept();
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            )
            {
                
                System.out.println("Socket Accepted!");
                //String phoneMac = in.readLine();
                //String phoneTime = in.readLine();
                String phonePostcode = in.readLine();
                queryData(phonePostcode);
                for (int i = 0; i < dataListArray.size(); i++) {
                    for (int j = 0; j < 4; j++) {
                        String data = dataListArray.get(i).get(j);
                        out.println(data);
                        System.out.println(data);
                    }
                    /*
                    //price
                    String price = dataListArray.get(i).get(0);
                    out.println(dataLine.get(0));
                    System.out.println(dataLine.get(0));
                    //postcode
                    out.println(dataLine.get(1));
                    System.out.println(dataLine.get(1));
                    //address
                    out.println(dataLine.get(2));
                    System.out.println(dataLine.get(2));
                    //date
                    out.println(dataLine.get(3));
                    System.out.println(dataLine.get(3));
                    */
                }
                /*
                phoneInputs[0] = phoneMac;
                phoneInputs[1] = phoneTime;
                phoneInputs[2] = phonePostcode;
                 */
                
            } catch (IOException e) {
                System.out.println("Exception caught when trying to listen on port " + "55555" + " or listening for a connection");
                System.out.println(e.getMessage());
            }
        }
    }
    
    /**
     *
     * @param postcode
     */
    public void queryData(String postcode)
    {
        String firstHalfOfPostcode = postcode.substring(0,postcode.indexOf(" "));
        try
        {
            // Should be of the form: SELECT * FROM LANDREGISTRYDATATABLE WHERE POSTCODE LIKE 'MK13%'
            // Vulnerable to SQL injection - Don't currently know how to solve
            Statement stmt = con.createStatement();
            String SQL = ("SELECT * FROM PRICEPAIDTABLE WHERE POSTCODE LIKE " + "'" + firstHalfOfPostcode + " %" + "'");
            ResultSet rs = stmt.executeQuery( SQL );
            
            ////// Printing out all records while rs.next() is true
            
            while(rs.next())
            {
                ArrayList<String> dataList = new ArrayList();
                dataList.add(Integer.toString(rs.getInt("PRICE")));
                dataList.add(rs.getString("POSTCODE"));
                dataList.add(rs.getString("ADDRESS"));
                dataList.add(Integer.toString(rs.getInt("DATE")));
                //System.out.println(dataList);
                dataListArray.add(dataList);
                System.out.println(dataListArray);
            }
            
            stmt.close();
            rs.close();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(PricePaidDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        //#######################################################################        
        
    } // End of queryData
    
    /*public void parseLine(String line){
        try{
            ArrayList<String> tokens = new ArrayList<String>();
            StreamTokenizer st = new StreamTokenizer(new StringReader(line));
            boolean eof = false;
            boolean eol = false;
            int token;
            String tokenChar;
            tokens.clear();
            
            /*while(!eof){
                while(!eol){
                token = st.nextToken();
                switch(token){
                    case StreamTokenizer.TT_EOF:
                        eof = true;
                        break;
                    case StreamTokenizer.TT_EOL:
                        eol = true;
                        break;
                    /*case StreamTokenizer.TT_NUMBER:
                        tokenChar = st.sval;
                        System.out.println(tokenChar);
                    case StreamTokenizer.TT_WORD:
                        //tokenChar = st.sval;
                        System.out.println(st);
                        while(true){
                            
                        }
                    }
                }
            }
        } catch(IOException e){
            System.out.println(e.getMessage());
        }
    }*/
}
