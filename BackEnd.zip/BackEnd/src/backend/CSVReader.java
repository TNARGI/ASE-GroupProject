package backend;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader
{

    
    public static void main(String[] args)
    {
        
        /*
        String csvFile = "C:/users/toshiba/documents/msc/test.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";

        try
        {
            Database db = new Database();

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null)
            {

                // use comma as separator
                String[] country = line.split(cvsSplitBy);
                
                db.storeData(country[3], country[1]);
                

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        */

    } // End of main

    
    
    public void storeLandRegistryData()
    {
        // Using a test file that contains the first 10 rows of the 3.5GB file
        String csvFile = "C:/LR-price-paid-full.csv";
        BufferedReader br = null;
        String line;
       

        try
        {
            Database db = new Database();

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null)
            {

                // use comma as separator
                String[] data = line.split(",");
                
                db.storeData
                (
                        data[0], data[1], data[2], data[3], data[4],
                        data[5], data[6], data[7], data[8], data[9],
                        data[10], data[11], data[12], data[13], data[14],
                        data[15]
                );
                

            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
    } // End of storeLandResgistryData
    
        
    
} // End of CSVReader
