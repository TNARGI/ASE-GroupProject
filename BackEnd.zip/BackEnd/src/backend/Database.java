/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author toshiba
 */
public class Database
{
    
    ////// PROBABLY NOT NECESSARY
    /*
    public void recallRecords()
    {
        
        try
        {
            String host = "jdbc:derby://localhost:1527/LANDREGISTRYDATABASE";
            String username = "TNARGI";
            String password = "Databas3";
            
            Connection con = DriverManager.getConnection(host, username, password);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            String SQL = "SELECT * FROM LANDREGISTRYDATATABLE";
            ResultSet rs = stmt.executeQuery( SQL );
            
            
            ////// Printing out all records while rs.next() is true
            while(rs.next())
            {
                String pCode = rs.getString("LATITUDE");
                //rs.updateString("VALUE", "manual update");
                String val = rs.getString("LONGITUDE");
                
                
                System.out.println(pCode+" "+val);
            }
            
            stmt.close();
            rs.close();
            
        }
        catch (SQLException ex)
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    } // End of recallRecords
    */
    
    
    
    public void storeData
        (
                String transID, String price, String datetime, String postcode,
                String propertyType, String newBuild, String freeOrLeasehold,
                String paon, String saon, String street, String locality,
                String townOrCity, String district, String county,
                String ppdCategory, String recordStatus
        )
    {
        try
        {
            
            String host = "jdbc:derby://localhost:1527/LANDREGISTRYDATABASE";
            String username = "TNARGI";
            String password = "Databas3";
            
            Connection con = DriverManager.getConnection(host, username, password);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            String SQL = "SELECT * FROM LANDREGISTRYDATATABLE";
            ResultSet rs = stmt.executeQuery( SQL );
            
            
            rs.moveToInsertRow();
            rs.updateString("TRANSACTION_ID", transID);
            rs.updateString("PRICE", price);
            rs.updateString("DATETIME", datetime);
            rs.updateString("POSTCODE", postcode);
            rs.updateString("PROPERTYTYPE", propertyType);
            rs.updateString("NEWBUILD", newBuild);
            rs.updateString("FREEHOLDORLEASEHOLD", freeOrLeasehold);
            rs.updateString("PAON", paon);
            rs.updateString("SAON", saon);
            rs.updateString("STREET", street);
            rs.updateString("LOCALITY", locality);
            rs.updateString("TOWNORCITY", townOrCity);
            rs.updateString("DISTRICT", district);
            rs.updateString("COUNTY", county);
            rs.updateString("PPDCATEGORY", ppdCategory);
            rs.updateString("RECORDSTATUS", recordStatus);
            
            // Insert updateStrings above into table
            rs.insertRow();
            
            // Close Statement and ResultsSet objects to assist data storage
            stmt.close();
            rs.close();
            
            //System.out.println("##### NEW RECORD ADDED #####");
        }
        catch(SQLException ex)
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }

        
    } // End of storeData
    
        
        
    public void clearData()
    {
        try
        {
            
            String host = "jdbc:derby://localhost:1527/LANDREGISTRYDATABASE";
            String username = "TNARGI";
            String password = "Databas3";
            
            Connection con = DriverManager.getConnection(host, username, password);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
                        
            stmt.executeUpdate("DELETE FROM LANDREGISTRYDATATABLE");
            
            // Close Statement object to assist update
            stmt.close();
            
            System.out.println("##### RECORDS DELETED #####");
        }
        catch(SQLException ex)
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }

    } // End of clearData
    
    
    
    public void queryData(String postcode)
    {
        String firstHalfOfPostcode = postcode.substring(0,4);
        
        
        try
        {
            String host = "jdbc:derby://localhost:1527/LANDREGISTRYDATABASE";
            String username = "TNARGI";
            String password = "Databas3";
            
            Connection con = DriverManager.getConnection(host, username, password);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            
            // Should be of the form: SELECT * FROM LANDREGISTRYDATATABLE WHERE POSTCODE LIKE 'MK13%'
            // Vulnerable to SQL injection - Don't currently know how to solve
            String SQL = ("SELECT * FROM LANDREGISTRYDATATABLE WHERE POSTCODE LIKE " + "'" + firstHalfOfPostcode + "%" + "'");
            ResultSet rs = stmt.executeQuery( SQL );
            
            ////// Printing out all records while rs.next() is true
            while(rs.next())
            {
                String pCode = rs.getString("POSTCODE");               
                
                System.out.println("postcode: " + pCode);
            }
            
            stmt.close();
            rs.close();
            
        }
        catch (SQLException ex)
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        //#######################################################################        
        
    } // End of queryData
        
        
        
        
        
    
    ////// PROBABLY NOT NEEDED - MAINLY USED FOR TESTING
    /*
    public void printLastDataRecord()
    {
        try
        {
            
            String host = "jdbc:derby://localhost:1527/LANDREGISTRYDATABASE";
            String username = "TNARGI";
            String password = "Databas3";
            
            Connection con = DriverManager.getConnection(host, username, password);
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            String SQL = "SELECT * FROM LANDREGISTRYDATATABLE";
            ResultSet rs = stmt.executeQuery( SQL );
            
            
            rs.last();
            String pCode = rs.getString("POSTCODE");
            String val = rs.getString("VALUE");
            
            
            System.out.println(pCode+" "+val);

            
            stmt.close();
            rs.close();
            
            System.out.println("##### LAST RECORD PRINTED #####");
        }
        catch(SQLException ex)
        {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    } // End of printLastDataRecord
    */

    
    

} // End of Database
