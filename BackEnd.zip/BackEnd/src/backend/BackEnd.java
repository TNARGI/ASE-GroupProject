package backend;
import java.io.*;
import java.net.*;
public class BackEnd
{
    static String filePath = "C:/App Records";
    int portNumber = 23456;
    
    public static void main(String[] args) throws Exception {
        
        
        
        // TESTING LAND REGISTRY DATA UPLOAD
        //#####################################################################
        
        clearTableAndLoadLRData();
        
        
        
        //listenForPhones();
        
        
        
        //#####################################################################

        
        
        
        
        
        ////// COMMENTED OUT FOR TESTING - TYRING TO LOAD LAND REGISTRY DATA
        /*
        //If directory does not exist, create directory:
        File appDir = new File(filePath);
        appDir.mkdir();
        
        while(true)
        {
        try (
            ServerSocket serverSocket = new ServerSocket(23456);
            Socket clientSocket = serverSocket.accept();
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        ) {
            System.out.println("Socket Accepted!");
            String phoneMac = in.readLine();
            String phoneTime = in.readLine();
            String latitude = in.readLine();
            String longitude = in.readLine();
            addRecord(phoneMac, phoneTime, latitude, longitude);
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port " + "55555" + " or listening for a connection");
            System.out.println(e.getMessage());
        }
        }*/
    }
    
    ////// COMMENTED OUT FOR TESTING - TRYING TO LOAD LAND REGISTRY DATA
    /*
    public static void addRecord(String phoneMac, String phoneTime, String latitude, String longitude) throws Exception
    {
        //Add new record to directory:
        long longTime = System.currentTimeMillis();
        String serverTime = Long.toString(longTime);
        //Test filepath:
        System.out.println(filePath + "/" + serverTime + ".txt");
        File appRec = new File(filePath + "/" + serverTime + ".txt");
        appRec.createNewFile();
        FileOutputStream out = new FileOutputStream(appRec);
        String text = phoneMac + "; " + serverTime + "; " + phoneTime + "; " + latitude + "; " + longitude;
        byte buffer [] = text.getBytes();
        out.write(buffer);
        out.close();
    } // End of addRecord
    */
    
    
    public static void clearTableAndLoadLRData()
    {
        CSVReader csvreader = new CSVReader();
        Database db = new Database();
        
        //db.clearData();
        csvreader.storeLandRegistryData();
        
        
        // TESTING THE QUERY DATA METHOD USING A POSTCODE PARAMETER
        // SHOULD SEARCH THE DATABASE FOR ALL RECORDS WITH THE SAME FIRST 4 CHARACTERS
        //db.queryData("MK13 7WZ");
    }
    
    
    public static void listenForPhones()
    {
        while(true)
        {
        try (
            ServerSocket serverSocket = new ServerSocket(23456);
            Socket clientSocket = serverSocket.accept();
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        ) {
            System.out.println("Socket Accepted!");
            String phoneMac = in.readLine();
            String phoneTime = in.readLine();
            String phonePostcode = in.readLine();
            //db.queryData(phonePostcode);
            /*String latitude = in.readLine();
            String longitude = in.readLine();*/
            //addRecord(phoneMac, phoneTime, latitude, longitude);
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port " + "55555" + " or listening for a connection");
            System.out.println(e.getMessage());
        }
        }
        
    } // End of listenForPhones
    
} // End of BackEnd